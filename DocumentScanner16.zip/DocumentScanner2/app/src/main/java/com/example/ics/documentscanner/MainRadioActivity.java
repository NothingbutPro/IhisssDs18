package com.example.ics.documentscanner;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainRadioActivity extends AppCompatActivity {
    Button account_rd, income_tx;
  CardView card1 ,card2;
    ImageView acc_btn, income_btn;
    PopupWindow popupWindow;
    EditText customer_edit_id,customerId;
    RelativeLayout popup_linear;
    RadioGroup clientType;
    RadioButton newClient, existingClient;
    TextView btn_ok,bt_ok;
    String Condition;
    String Id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainradio_activity);

     //   final Context c = MainRadioActivity.this;
        customer_edit_id = (EditText) findViewById(R.id.customer_edit_id);
        account_rd = (Button) findViewById(R.id.account_rd);
        card1 = (CardView)findViewById(R.id.card1);

        card2 = (CardView)findViewById(R.id.card2);

        income_tx = (Button) findViewById(R.id.income_tx);
        card2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent to_the_capture_i = new Intent(MainRadioActivity.this, FormActivity.class);
                startActivity(to_the_capture_i);
            }
        });

        card1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Dialog dialog = new Dialog(MainRadioActivity.this);
                dialog.setContentView(R.layout.custom_dialog);
                dialog.setTitle("Please choose your Type.");

                // set the custom dialog components - text, image and button
                clientType = (RadioGroup) dialog.findViewById(R.id.clientType);
                newClient = (RadioButton) dialog.findViewById(R.id.newClient);
                existingClient = (RadioButton) dialog.findViewById(R.id.existingClient);
                btn_ok = (TextView) dialog.findViewById(R.id.btn_ok);


                btn_ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        final int i = clientType.getCheckedRadioButtonId();
                        Log.e("ddddddddd", i + "");
                        if (R.id.newClient == i) {
                            dialog.dismiss();
                            Intent intent = new Intent(MainRadioActivity.this, AccountFormActivity.class);
                            startActivity(intent);

                        } else if (R.id.existingClient == i) {
                            dialog.dismiss();
                            //===============================
                            final Dialog dialog = new Dialog(MainRadioActivity.this);
                            dialog.setContentView(R.layout.existclientdialog);
                            dialog.setTitle("Please choose your Type.");

                            // set the custom dialog components - text, image and button
                            customerId = (EditText)dialog.findViewById(R.id.customerId);
                            bt_ok = (TextView) dialog.findViewById(R.id.bt_ok);

                            bt_ok.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    dialog.dismiss();
                                    Intent intent = new Intent(MainRadioActivity.this,MainActivity.class);
                                    startActivity(intent);
                                }
                            });

                            dialog.show();
                            //================================

                        }
                    }
                });

                dialog.show();
            }
        });

       /* account_rd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
       //instantiate the popup.xml layout file
                Button popup_id;
                LayoutInflater layoutInflaterAndroid = LayoutInflater.from(c);
                final View mView = layoutInflaterAndroid.inflate(R.layout.ask_customer_id_popup, null);
                customer_edit_id = (EditText)mView.findViewById(R.id.customer_edit_id);
                final AlertDialog.Builder alertDialogBuilderUserInput = new AlertDialog.Builder(c);
                alertDialogBuilderUserInput.setView(mView);
                alertDialogBuilderUserInput
                        .setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialogBox, int id) {
                                // ToDo get user input here
                                if(customer_edit_id.getText().toString().isEmpty() == false) {
                                    Intent to_the_capture = new Intent(MainRadioActivity.this, MainActivity.class);
                                    startActivity(to_the_capture);
                                }else{
                                    // make_it_again();
                                    Toast.makeText(MainRadioActivity.this, "Please specify your customer id", Toast.LENGTH_SHORT).show();
                                }
                            }

                            private void make_it_again() {
                                alertDialogBuilderUserInput.setView(mView);
                                alertDialogBuilderUserInput
                                        .setCancelable(false)
                                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                if(customer_edit_id.getText().toString().isEmpty() == false) {
                                                    Intent to_the_capture = new Intent(MainRadioActivity.this, MainActivity.class);
                                                    startActivity(to_the_capture);
                                                }else{
                                                    make_it_again();
                                                    Toast.makeText(MainRadioActivity.this, "Please specify your customer id", Toast.LENGTH_SHORT).show();
                                                }
                                            }
                                        });

                            }

                        });
                AlertDialog alertDialogAndroid = alertDialogBuilderUserInput.create();
                alertDialogAndroid.show();
            }
        });*/

    }

}
