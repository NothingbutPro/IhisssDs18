package com.example.ics.documentscanner;

import android.Manifest;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.regex.Pattern;

import static com.example.ics.documentscanner.RuntimePermission.hasPermissions;

public class GetMailActivity extends AppCompatActivity {
    private static final int PERMISSION_ALL = 1 ;
    ProgressDialog progressDialog;
    private String TAG = "AccountsActivityTAG";
    private String wantPermission = Manifest.permission.GET_ACCOUNTS;
    private Activity activity = GetMailActivity.this;
    private static final int PERMISSION_REQUEST_CODE = 1;
    private String get_email;
    TextView email_address_view;
    private CardView ver_f_btn;
    private EditText num_edit;
    String put_num;
    String[] PERMISSIONS = {Manifest.permission.CAMERA,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.CALL_PHONE};
    String URLString = "https://www.spellclasses.co.in/DM/Api/insert_customer";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_mail);
        ver_f_btn = (CardView) findViewById(R.id.ver_f_btn);
        num_edit = (EditText) findViewById(R.id.num_edit);
        put_num = num_edit.getText().toString();
        ver_f_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (num_edit.getText().toString().isEmpty() == false) {
                    Toast.makeText(GetMailActivity.this, "Feilds are empty", Toast.LENGTH_SHORT).show();
                    Toast.makeText(GetMailActivity.this, "" + put_num, Toast.LENGTH_SHORT).show();
                    getEmails(put_num);
                } else {
                    Toast.makeText(GetMailActivity.this, "Please specify your mobile number", Toast.LENGTH_SHORT).show();
                }
            }
        });
        if (!checkPermission(wantPermission)) {
            requestPermission(wantPermission);
        } else {
            //getEmails();
        }

        checkAndRequestPermissions();

    }

    private void getEmails(String mobile_number) {
        Pattern emailPattern = Patterns.EMAIL_ADDRESS;

        // Getting all registered Google Accounts;
        // Account[] accounts = AccountManager.get(this).getAccountsByType("com.google");

        // Getting all registered Accounts;
        Account[] accounts = AccountManager.get(this).getAccounts();

        for (Account account : accounts) {
            if (emailPattern.matcher(account.name).matches()) {
                Log.d(TAG, String.format("%s - %s", account.name, account.type));
                email_address_view = (TextView) findViewById(R.id.email_address_view);
                email_address_view.setText(account.name);
                if (account.name != null && mobile_number != null) {
                    progressDialog = new ProgressDialog(GetMailActivity.this);
                    progressDialog.setMessage("" + account.name); // Setting Message
                    progressDialog.setTitle("Verifying"); // Setting Title
                    progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER); // Progress Dialog Style Spinner
                    progressDialog.show(); // Display Progress Dialog
                    progressDialog.setCancelable(false);
                    new Thread(new Runnable() {
                        public void run() {
                            try {
                                Thread.sleep(5000);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            progressDialog.dismiss();
                            if (num_edit.getText().toString().isEmpty() == false) {

                                new Post_number().execute();
                                Intent go_to_main = new Intent(GetMailActivity.this, MainRadioActivity.class);
                                String number = num_edit.getText().toString();
                                if (num_edit.getText().toString().isEmpty() == true) {
                                    Toast.makeText(GetMailActivity.this, "Field Vaccant", Toast.LENGTH_LONG).show();
                                    return;
                                } else {


                                }
                                startActivity(go_to_main);
                            }

                        }
                    }).start();
                } else {
                    Toast.makeText(GetMailActivity.this, "Please specify your mobile number", Toast.LENGTH_SHORT).show();

                }
            }

        }
    }


    private boolean checkPermission(String permission) {
        if (Build.VERSION.SDK_INT >= 23) {
            int result = ContextCompat.checkSelfPermission(activity, permission);
            if (result == PackageManager.PERMISSION_GRANTED) {
                return true;
            } else {
                return false;
            }
        } else {
            return true;
        }
    }

    private void requestPermission(String permission) {
        if (ActivityCompat.shouldShowRequestPermissionRationale(GetMailActivity.this, permission)) {
            Toast.makeText(GetMailActivity.this, "Get account permission allows us to get your email", Toast.LENGTH_LONG).show();
        }
        ActivityCompat.requestPermissions(GetMailActivity.this, new String[]{permission}, PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (num_edit.getText().toString().isEmpty() == false) {
                     //   Toast.makeText(GetMailActivity.this, "" + put_num, Toast.LENGTH_SHORT).show();
                      //  Toast.makeText(GetMailActivity.this, "Feilds are empty", Toast.LENGTH_SHORT).show();
                        getEmails(num_edit.getText().toString());
                    }
                 //   Toast.makeText(GetMailActivity.this, "got it", Toast.LENGTH_LONG).show();
                } else {
                   // Toast.makeText(GetMailActivity.this, "Permission Denied.", Toast.LENGTH_LONG).show();
                }
                break;
        }
    }


    private class Post_number extends AsyncTask<Void, Void, Void> {
        String Info;
        ProgressDialog pDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            //   pDialog = ProgressDialog.show(getBaseContext(),"","Please Wait..Connecting to the server",true);
            //  pDialog.setCancelable(true);
        }

        @Override
        protected Void doInBackground(Void... voids) {
            HashMap<String, Object> number_to_post = new HashMap<>();
            String mobile = num_edit.getText().toString();
            number_to_post.put("mobile", mobile);
            Connection connection = new Connection();
            String result = connection.sendpostRequst(URLString, number_to_post);
            System.out.println(result);
            try {
                JSONObject object = new JSONObject(result);
                Info = object.getString("info");

            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
//            pDialog.dismiss();
            //  Toast.makeText(GetMailActivity.this, Info, Toast.LENGTH_LONG).show();
            super.onPostExecute(aVoid);
        }
    }

    //-------------------------------------------------

    private void checkAndRequestPermissions() {
        if (!hasPermissions(this, PERMISSIONS)) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
        }
    }
}


