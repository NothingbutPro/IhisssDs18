package com.example.ics.documentscanner;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Locale;

import javax.net.ssl.HttpsURLConnection;

public class FormActivity extends AppCompatActivity {
    Toolbar toolbar_income;
    Calendar myCalendar;
    ProgressDialog dialog;
    DatePickerDialog.OnDateSetListener date;
    private String dateFlage;
    EditText nameAssessee,fatherName,address,email_,status,pan,residentailStatus,aadharNo,dateofBirth,sex,passportNo,tele,password,
            bank,bankLocation,accountNo,micrNo,ifsc,type;
    String NameAssessee,FatherName,Address,Email_,Status,Pan,ResidentailStatus,AadharNo,DateofBirth,Sex,PassportNo,Tele,Password,
            Bank,BankLocation,AccountNo,MicrNo,Ifsc,Type;
    Button submit ,skip;
    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        toolbar_income = (Toolbar) findViewById(R.id.toolbar_income);

        toolbar_income.setNavigationIcon(R.drawable.arrow);

        toolbar_income.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        nameAssessee = (EditText)findViewById(R.id.nameAssessee);
        fatherName = (EditText)findViewById(R.id.fatherName);
        address = (EditText)findViewById(R.id.address);
        email_ = (EditText)findViewById(R.id.email_);
        status = (EditText)findViewById(R.id.status);
        pan = (EditText)findViewById(R.id.pan);
        residentailStatus = (EditText)findViewById(R.id.residentailStatus);
        aadharNo = (EditText)findViewById(R.id.aadharNo);
        dateofBirth = (EditText)findViewById(R.id.dateofBirth);
        sex = (EditText)findViewById(R.id.sex);
        passportNo = (EditText)findViewById(R.id.passportNo);
        tele = (EditText)findViewById(R.id.tele);
        password = (EditText)findViewById(R.id.password);
        bank = (EditText)findViewById(R.id.bank);
        bankLocation = (EditText)findViewById(R.id.bankLocation);
        accountNo = (EditText)findViewById(R.id.accountNo);
        micrNo = (EditText)findViewById(R.id.micrNo);
        ifsc = (EditText)findViewById(R.id.ifsc);
        type = (EditText)findViewById(R.id.type);
        submit = (Button)findViewById(R.id.submit);
        skip = (Button)findViewById(R.id.skip);

        picDate();

        builder = new AlertDialog.Builder(FormActivity.this);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                NameAssessee = nameAssessee.getText().toString();
                FatherName = fatherName.getText().toString();
                Address = address.getText().toString();
                Email_ = email_.getText().toString();
                Status = status.getText().toString();
                Pan = pan.getText().toString();
                ResidentailStatus = residentailStatus.getText().toString();
                AadharNo = aadharNo.getText().toString();
                DateofBirth = dateofBirth.getText().toString();
                Sex = sex.getText().toString();
                PassportNo = passportNo.getText().toString();
                Tele = tele.getText().toString();
                Password = password.getText().toString();
                Bank = bank.getText().toString();
                BankLocation = bankLocation.getText().toString();
                AccountNo = accountNo.getText().toString();
                MicrNo = micrNo.getText().toString();
                Ifsc = ifsc.getText().toString();
                Type = type.getText().toString();

                if (Connectivity.isNetworkAvailable(FormActivity.this)) {
                    new PostForm().execute();
               }else {
                Toast.makeText(FormActivity.this, "no internet", Toast.LENGTH_SHORT).show();

                 }
            }
        });

        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Uncomment the below code to Set the message and title from the strings.xml file
             //   builder.setMessage(R.string.dialog_message).setTitle(R.string.dialog_title);

                //Setting message manually and performing action on button click
                builder.setMessage("Please upload last year Income Tax return copy.")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                              Intent intent = new Intent(FormActivity.this,MainActivity.class);
                              startActivity(intent);

                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //  Action for 'NO' Button
                                dialog.cancel();

                            }
                        });
                //Creating dialog box
                AlertDialog alert = builder.create();
                //Setting the title manually
              //  alert.setTitle("AlertDialogExample");
                alert.show();
            }
        });

    }

    //=============================

    private void picDate() {

        myCalendar = Calendar.getInstance();

        date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }

        };

        dateofBirth.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dateFlage="1";
                new DatePickerDialog(FormActivity.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

    }

    private void updateLabel() {

        if (dateFlage.equalsIgnoreCase("1")){
            String myFormat = "yyyy-MM-dd"; //In which you need put here
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, new Locale("pt", "BR"));
            dateofBirth.setText(sdf.format(myCalendar.getTime()));
        }
    }

    //=========================

    public class PostForm extends AsyncTask<String, Void, String> {
        ProgressDialog dialog;

        protected void onPreExecute() {
            dialog = new ProgressDialog(FormActivity.this);
            dialog.show();

        }

        protected String doInBackground(String... arg0) {

            try {

                URL url = new URL("https://www.spellclasses.co.in/DM/Api/taxreturn");

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("name_of_acceesee", NameAssessee);
                postDataParams.put("father", FatherName);
                postDataParams.put("address", Address);
                postDataParams.put("email", Email_);
                postDataParams.put("status", Status);
                postDataParams.put("pan", Pan);
                postDataParams.put("residential_status", ResidentailStatus);
                postDataParams.put("adhar_no", AadharNo);
                postDataParams.put("telephone",Tele);
                postDataParams.put("dob", DateofBirth);
                postDataParams.put("sex" , Sex);
                postDataParams.put("passport_no" , PassportNo);
                postDataParams.put("password" , Password);
                postDataParams.put("bank" , Bank);
                postDataParams.put("bank_location" , BankLocation);
                postDataParams.put("ac_no" , AccountNo);
                postDataParams.put("micr_no" , MicrNo);
                postDataParams.put("ifsc_code" , Ifsc);
                postDataParams.put("type" , Type);
                postDataParams.put("emp_id" , "emp_id");
                postDataParams.put("cust_id" , "emp_id");


                Log.e("postDataParams", postDataParams.toString());

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000  /*milliseconds*/);
                conn.setConnectTimeout(15000  /*milliseconds*/);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = conn.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {

                    BufferedReader in = new BufferedReader(new
                            InputStreamReader(
                            conn.getInputStream()));

                    StringBuffer sb = new StringBuffer("");
                    String line = "";

                    while ((line = in.readLine()) != null) {

                        StringBuffer Ss = sb.append(line);
                        Log.e("Ss", Ss.toString());
                        sb.append(line);
                        break;
                    }

                    in.close();
                    return sb.toString();

                } else {
                    return new String("false : " + responseCode);
                }
            } catch (Exception e) {
                return new String("Exception: " + e.getMessage());
            }

        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                dialog.dismiss();

                JSONObject jsonObject = null;
                Log.e("PostRegistration", result.toString());
                try {

                    jsonObject = new JSONObject(result);
                    String response = jsonObject.getString("response");
                    String message = jsonObject.getString("message");


                    if (response.equalsIgnoreCase("True")) {
                        Intent intent = new Intent(FormActivity.this, MainActivity.class);
                        startActivity(intent);
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }

        public String getPostDataString(JSONObject params) throws Exception {

            StringBuilder result = new StringBuilder();
            boolean first = true;

            Iterator<String> itr = params.keys();

            while (itr.hasNext()) {

                String key = itr.next();
                Object value = params.get(key);

                if (first)
                    first = false;
                else
                    result.append("&");

                result.append(URLEncoder.encode(key, "UTF-8"));
                result.append("=");
                result.append(URLEncoder.encode(value.toString(), "UTF-8"));

            }
            return result.toString();
        }
    }

    //-------------------------------

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
