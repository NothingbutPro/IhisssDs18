package com.example.ics.documentscanner;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.AsyncTask;
import android.provider.ContactsContract;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ics.documentscanner.Sharedprefrence.SessionManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;

import javax.net.ssl.HttpsURLConnection;

public class MainRadioActivity extends AppCompatActivity {
    Button account_rd, income_tx;
    CardView card1, card2;
    ImageView acc_btn, income_btn;
    PopupWindow popupWindow;
    EditText customer_edit_id, customerId;
    RelativeLayout popup_linear;
    RadioGroup clientType;
    RadioButton newClient, existingClient;
    TextView btn_ok, bt_ok1, bt_ok, btn_ok1;
    SharedPreferences sharedpreferences_cus;
    public static final String cus_preferences = "cus_code";
    public static final String Name = "cus_key";
    SharedPreferences.Editor editor;
    SessionManager sessionManager;
    TextView cus;
    String Condition;
    ImageButton exit_from;
    String Id;
    String cs;
    String cs_get_in;
    EditText customerId_tax;
    String CustomerId, cs_get;
    RadioGroup clientType1;
    RadioButton newClient1;
    RadioButton existingClient1;

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
        super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainradio_activity);
        //++++++++++++++++++++++++++++++++++++For shared reference+++++++++++++++++++++++++++++++++++++++++++++
        exit_from = (ImageButton) findViewById(R.id.exit_from);
        exit_from.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveTaskToBack(true);
                System.exit(0);
            }
        });
//        sharedpreferences_cus = getSharedPreferences(cus_preferences,
//                Context.MODE_PRIVATE);
//        editor = sharedpreferences_cus.edit();
//        Id = getIntent().getStringExtra("cus_code");
//        editor.putString(cus_preferences , Id);
//        editor.commit();
        //   final Context c = MainRadioActivity.this;
        customer_edit_id = (EditText) findViewById(R.id.customer_edit_id);
        account_rd = (Button) findViewById(R.id.account_rd);
        card1 = (CardView) findViewById(R.id.card1);

        card2 = (CardView) findViewById(R.id.card2);

        income_tx = (Button) findViewById(R.id.income_tx);
        card2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Dialog dialog = new Dialog(MainRadioActivity.this);
                dialog.setContentView(R.layout.custom_layout_income);
                dialog.setTitle("Please choose your Type.");
                // set the custom dialog components - text, image and button
                clientType1 = (RadioGroup) dialog.findViewById(R.id.clientType1);
                newClient1 = (RadioButton) dialog.findViewById(R.id.newClient1);
                existingClient1 = (RadioButton) dialog.findViewById(R.id.existingClient1);
                btn_ok1 = (TextView) dialog.findViewById(R.id.btn_ok1);
                btn_ok1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        final int k = clientType1.getCheckedRadioButtonId();
                        Log.e("ddddddddd", k + "");
                        if (R.id.newClient1 == k) {
                            dialog.dismiss();
                            Intent intent = new Intent(MainRadioActivity.this, FormActivity.class);
                            startActivity(intent);

                        } else if (R.id.existingClient1 == k) {
                            dialog.dismiss();
                            //===============================
                            final Dialog dialog = new Dialog(MainRadioActivity.this);
                            dialog.setContentView(R.layout.existclientdialogincome);
                            dialog.setTitle("Please choose your Type.");

                            // set the custom dialog components - text, image and button
                            customerId_tax = (EditText) dialog.findViewById(R.id.customerId_tax);
                            bt_ok = (TextView) dialog.findViewById(R.id.bt_ok);

                            bt_ok.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {

                                     cs_get_in = customerId_tax.getText().toString();

                                    if (!customerId_tax.getText().toString().isEmpty()) {
                                        if (Connectivity.isNetworkAvailable(MainRadioActivity.this)) {
                                            new PostTaxExistingCustomer().execute();
                                        } else {
                                            Toast.makeText(MainRadioActivity.this, "No Internet", Toast.LENGTH_SHORT).show();
                                        }
                                    } else {
                                        Toast.makeText(MainRadioActivity.this, "IncomeTax id is either null or customer is not registered", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });

                            dialog.show();
                            //================================
                        }
                    }
                });
                dialog.show();
            }
        });


        card1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Dialog dialog = new Dialog(MainRadioActivity.this);
                dialog.setContentView(R.layout.custom_dialog);
                dialog.setTitle("Please choose your Type.");
                // set the custom dialog components - text, image and button
                clientType = (RadioGroup) dialog.findViewById(R.id.clientType);
                newClient = (RadioButton) dialog.findViewById(R.id.newClient);
                existingClient = (RadioButton) dialog.findViewById(R.id.existingClient);
                btn_ok = (TextView) dialog.findViewById(R.id.btn_ok);

                //   Toast.makeText(MainRadioActivity.this, "Your ID is "+Id, Toast.LENGTH_SHORT).show();

                btn_ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        final int i = clientType.getCheckedRadioButtonId();
                        Log.e("ddddddddd", i + "");
                        if (R.id.newClient == i) {
                            dialog.dismiss();
                            Intent intent = new Intent(MainRadioActivity.this, AccountFormActivity.class);
                            startActivity(intent);

                        } else if (R.id.existingClient == i) {
                            dialog.dismiss();
                            //===============================
                            final Dialog dialog = new Dialog(MainRadioActivity.this);
                            dialog.setContentView(R.layout.existclientdialog);
                            dialog.setTitle("Please choose your Type.");

                            // set the custom dialog components - text, image and button
                            customerId = (EditText) dialog.findViewById(R.id.customerId);
                            bt_ok1 = (TextView) dialog.findViewById(R.id.bt_ok1);

                            bt_ok1.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {

                                    cs_get = customerId.getText().toString();

                                    if (!customerId.getText().toString().isEmpty()) {
                                        if (Connectivity.isNetworkAvailable(MainRadioActivity.this)) {
                                            new PostExistingCustomer().execute();
                                        } else {
                                            Toast.makeText(MainRadioActivity.this, "No Internet", Toast.LENGTH_SHORT).show();
                                        }
                                    } else {
                                        Toast.makeText(MainRadioActivity.this, "Customer id is either null or customer is not registered", Toast.LENGTH_SHORT).show();
                                    }

                                }
                            });

                            dialog.show();
                            //================================
                        }
                    }
                });

                dialog.show();
            }
        });

    }

    //============================================================

    public class PostExistingCustomer extends AsyncTask<String, Void, String> {
        ProgressDialog dialog;

        protected void onPreExecute() {
            dialog = new ProgressDialog(MainRadioActivity.this);
            dialog.show();

        }

        protected String doInBackground(String... arg0) {

            try {

                URL url = new URL("http://ihisaab.com/Api/checkaccountuser");

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("cust_code", cs_get);

                Log.e("postDataParams", postDataParams.toString());

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000 /* milliseconds*/);
                conn.setConnectTimeout(15000  /*milliseconds*/);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = conn.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {

                    BufferedReader in = new BufferedReader(new
                            InputStreamReader(
                            conn.getInputStream()));

                    StringBuffer sb = new StringBuffer("");
                    String line = "";

                    while ((line = in.readLine()) != null) {

                        StringBuffer Ss = sb.append(line);
                        Log.e("Ss", Ss.toString());
                        sb.append(line);
                        break;
                    }

                    in.close();
                    return sb.toString();

                } else {
                    return new String("false : " + responseCode);
                }
            } catch (Exception e) {
                return new String("Exception: " + e.getMessage());
            }

        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                dialog.dismiss();

                JSONObject jsonObject = null;
                Log.e("PostPIinsuranceDetails", result.toString());
                try {

                    jsonObject = new JSONObject(result);
                    String response = jsonObject.getString("response");
                    if (response.equalsIgnoreCase("true")) {
                        JSONObject data_obj = jsonObject.getJSONObject("data");
                        String id = data_obj.getString("id");
                        String employee_id = data_obj.getString("employee_id");
                        String cust_code = data_obj.getString("cust_code");
                        String name = data_obj.getString("name");
                        String email = data_obj.getString("email");
                        String mobile = data_obj.getString("mobile");
                        String location = data_obj.getString("location");
                        String landmark = data_obj.getString("landmark");
                        String pan = data_obj.getString("pan");
                        String gst = data_obj.getString("gst");
                        String status = data_obj.getString("status");
                        String created = data_obj.getString("created");
                        String modified = data_obj.getString("modified");

                        Intent intent = new Intent(MainRadioActivity.this, MainActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(MainRadioActivity.this, "Invalid User", Toast.LENGTH_SHORT).show();
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }

        public String getPostDataString(JSONObject params) throws Exception {

            StringBuilder result = new StringBuilder();
            boolean first = true;

            Iterator<String> itr = params.keys();

            while (itr.hasNext()) {

                String key = itr.next();
                Object value = params.get(key);

                if (first)
                    first = false;
                else
                    result.append("&");

                result.append(URLEncoder.encode(key, "UTF-8"));
                result.append("=");
                result.append(URLEncoder.encode(value.toString(), "UTF-8"));

            }
            return result.toString();
        }
    }

    //-----------------------------------------------------------------


    public class PostTaxExistingCustomer extends AsyncTask<String, Void, String> {
        ProgressDialog dialog;

        protected void onPreExecute() {
            dialog = new ProgressDialog(MainRadioActivity.this);
            dialog.show();

        }

        protected String doInBackground(String... arg0) {

            try {

                URL url = new URL("http://ihisaab.com/Api/checktaxuser");

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("pan_no", cs_get_in);

                Log.e("postDataParams", postDataParams.toString());

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000 /* milliseconds*/);
                conn.setConnectTimeout(15000  /*milliseconds*/);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = conn.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {

                    BufferedReader in = new BufferedReader(new
                            InputStreamReader(
                            conn.getInputStream()));

                    StringBuffer sb = new StringBuffer("");
                    String line = "";

                    while ((line = in.readLine()) != null) {

                        StringBuffer Ss = sb.append(line);
                        Log.e("Ss", Ss.toString());
                        sb.append(line);
                        break;
                    }

                    in.close();
                    return sb.toString();

                } else {
                    return new String("false : " + responseCode);
                }
            } catch (Exception e) {
                return new String("Exception: " + e.getMessage());
            }

        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                dialog.dismiss();

                JSONObject jsonObject = null;
                Log.e("PostPIinsuranceDetails", result.toString());
                try {

                    jsonObject = new JSONObject(result);
                    String response = jsonObject.getString("response");
                    if (response.equalsIgnoreCase("true")) {
                        JSONObject data_obj = jsonObject.getJSONObject("data");
                        String id = data_obj.getString("id");
                        String name = data_obj.getString("name");
                        String email = data_obj.getString("email");
                        String pan_no = data_obj.getString("pan_no");
                        String adhan_no = data_obj.getString("adhan_no");
                        String mobile = data_obj.getString("mobile");
                        String self_referal_code = data_obj.getString("self_referal_code");
                        String reference_referal_code = data_obj.getString("reference_referal_code");
                        String ret_email = data_obj.getString("ret_email");
                        String ret_mobile = data_obj.getString("ret_mobile");
                        String status = data_obj.getString("status");
                        String created = data_obj.getString("created");

                        Intent intent = new Intent(MainRadioActivity.this, Single_user_act_2.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(MainRadioActivity.this, "Invalid User", Toast.LENGTH_SHORT).show();
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }

        public String getPostDataString(JSONObject params) throws Exception {

            StringBuilder result = new StringBuilder();
            boolean first = true;

            Iterator<String> itr = params.keys();

            while (itr.hasNext()) {

                String key = itr.next();
                Object value = params.get(key);

                if (first)
                    first = false;
                else
                    result.append("&");

                result.append(URLEncoder.encode(key, "UTF-8"));
                result.append("=");
                result.append(URLEncoder.encode(value.toString(), "UTF-8"));

            }
            return result.toString();
        }
    }


}
