package com.example.ics.documentscanner;

import android.Manifest;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.InputFilter;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ics.documentscanner.Sharedprefrence.SessionManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Locale;
import java.util.regex.Pattern;

import javax.net.ssl.HttpsURLConnection;

import static com.example.ics.documentscanner.GetMailActivity.MyPREFERENCES;
import static com.example.ics.documentscanner.RuntimePermission.hasPermissions;

public class AccountFormActivity extends AppCompatActivity {
    private static final int PERMISSION_ALL = 1 ;
    Toolbar toolbar_account;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    String store;
    Calendar myCalendar;
    String name_str,email_str,pan_nostr,adhan_nostr,mobilestr,ret_emailstr,ret_mobilestr;
    ProgressDialog dialog;
    DatePickerDialog.OnDateSetListener date;
    String gm;
    EditText name,email,location,mobile,landmark,pan,gst;
    String Name,Email,Location,Mobile,Landmark,Pan,Gst;
    Button submit ,skip;
    private static final int PERMISSION_REQUEST_CODE = 1;
    AlertDialog.Builder builder;
   SessionManager sessionManager;
    private String wantPermission = Manifest.permission.GET_ACCOUNTS;
    String[] PERMISSIONS = {android.Manifest.permission.CAMERA,
            android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.GET_ACCOUNTS};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_form);
        sessionManager=new SessionManager(this);
        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
//        if(sharedpreferences.getString("cus_id" ,store ) != null){
//            Intent sp = new Intent(AccountFormActivity.this , MainActivity.class);
//            startActivity(sp);
//        }
        //
        // Email = email.getText().toString();
        Pattern emailPattern = Patterns.EMAIL_ADDRESS;

        Account[] accounts = AccountManager.get(AccountFormActivity.this).getAccounts();

        for (Account account : accounts) {
            if (emailPattern.matcher(account.name).matches()) {
                Log.d("Getting Account", String.format("%s - %s", account.name, account.type));
                gm = account.name;
//                            email = (EditText) findViewById(R.id.email);
//                            email.setText("" + gm, TextView.BufferType.EDITABLE);
//                            email.setClickable(false);

                //  email_address_view = (TextView) findViewById(R.id.email_address_view);
                //email_address_view.setText(account.name);
                //sessionManager.serverEmailLogin(account.name);
//                Intent go_to_main = new Intent(AccountFormActivity.this, MainRadioActivity.class);
//                go_to_main.putExtra("mob_to_ret",put_num);
//                go_to_main.putExtra("email_to_ret",account.name);
                //  Toast.makeText(GetMailActivity.this, ""+, Toast.LENGTH_SHORT).show();
                //new Post_number().execute();
//                startActivity(go_to_main);
                //  finish();

            }
        }

          //     getmail();

        toolbar_account = (Toolbar) findViewById(R.id.toolbar_account);

        toolbar_account.setNavigationIcon(R.drawable.arrow);

        toolbar_account.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        name = (EditText)findViewById(R.id.name);
        email = (EditText)findViewById(R.id.email);
        //email.setFocusable(false);
       // email.setClickable(false);
        location = (EditText)findViewById(R.id.location);
        mobile = (EditText)findViewById(R.id.mobile);
        landmark = (EditText)findViewById(R.id.landmark);
        pan = (EditText)findViewById(R.id.pan);
        gst = (EditText)findViewById(R.id.gst);
        submit = (Button)findViewById(R.id.submit);

        pan.setFilters(new InputFilter[]{new InputFilter.AllCaps()});
        
        builder = new AlertDialog.Builder(AccountFormActivity.this);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               // Intent intent = new Intent(AccountFormActivity.this, MainActivity.class);
             //   startActivity(intent);
                Name = name.getText().toString();
                 Email = gm;

                Location = location.getText().toString();
                Mobile = mobile.getText().toString();
                Landmark = landmark.getText().toString();
                Pan = pan.getText().toString();
                Gst = gst.getText().toString();


                if (Connectivity.isNetworkAvailable(AccountFormActivity.this)) {

                    if(name.getText().toString().isEmpty() || pan.getText().toString().isEmpty()){
                          if(Name.isEmpty()){
                              name.setError("Name should not be empty");
                          }
                          if(Pan.isEmpty() || pan.length() !=10){
                              pan.setError("Pan number should be exactly of 10 digit");
                          }
                            Toast.makeText(AccountFormActivity.this, "Fields should not be empty", Toast.LENGTH_SHORT).show();

                        }else if(pan.getText().length() == 10){
                        new PostForm().execute();
                    }
                }else {
                    Toast.makeText(AccountFormActivity.this, "no internet", Toast.LENGTH_SHORT).show();

                }
            }
        }
        );
    }

    private void getmail() {

    }
//end
    public class PostForm extends AsyncTask<String, Void, String> {
        ProgressDialog dialog;

        protected void onPreExecute() {
          //  dialog = new ProgressDialog(AccountFormActivity.this);
          //  dialog.show();

        }

        protected String doInBackground(String... arg0) {

            try {

                URL url = new URL("http://ihisaab.com/Api/accounting");

                JSONObject postDataParams = new JSONObject();
                postDataParams.put("name", Name);
                postDataParams.put("email", Email);
                postDataParams.put("mobile", Mobile);
                postDataParams.put("location", Location);
                postDataParams.put("landmark", Landmark);
                postDataParams.put("pan", Pan);
                postDataParams.put("gst", Gst);
//
//        // Getting all registered Google Accounts;
//        // Account[] accounts = AccountManager.get(this).getAccountsByType("com.google");
//
//        // Getting all registered Accounts;
//        Account[] accounts = AccountManager.get(this).getAccounts();


                Log.e("postDataParams", postDataParams.toString());

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000  /*milliseconds*/);
                conn.setConnectTimeout(15000  /*milliseconds*/);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);

                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = conn.getResponseCode();

                if (responseCode == HttpsURLConnection.HTTP_OK) {

                    BufferedReader in = new BufferedReader(new
                            InputStreamReader(
                            conn.getInputStream()));

                    StringBuffer sb = new StringBuffer("");
                    String line = "";

                    while ((line = in.readLine()) != null) {

                        StringBuffer Ss = sb.append(line);
                        Log.e("Ss", Ss.toString());
                        sb.append(line);
                        break;
                    }

                    in.close();
                    return sb.toString();

                } else {
                    return new String("false : " + responseCode);
                }
            } catch (Exception e) {
                return new String("Exception: " + e.getMessage());
            }

        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
              //  dialog.dismiss();

                JSONObject jsonObject = null;
                Log.e("PostRegistration", result.toString());
                try {

                    jsonObject = new JSONObject(result);
                    String response = jsonObject.getString("response");
                    String message = jsonObject.getString("message");
                    JSONObject dt = jsonObject.getJSONObject("data");
                    String cus_code = dt.getString("cust_code");
                 //   sessionManager.serverEmailLogin(cus_code);
//                    store = cus_code.toString();
//                    editor = sharedpreferences.edit();
//                    editor.putString("cus_code" , store);
                    Toast.makeText(AccountFormActivity.this, ""+cus_code, Toast.LENGTH_SHORT).show();
                    Log.e("Your Customer code is", cus_code);
                    if (response.equalsIgnoreCase("True")) {
                        Intent intent = new Intent(AccountFormActivity.this,MainActivity.class);
                        intent.putExtra("cus", cus_code);
                        startActivity(intent);
                      //  finish();
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }

        public String getPostDataString(JSONObject params) throws Exception {

            StringBuilder result = new StringBuilder();
            boolean first = true;

            Iterator<String> itr = params.keys();

            while (itr.hasNext()) {

                String key = itr.next();
                Object value = params.get(key);

                if (first)
                    first = false;
                else
                    result.append("&");

                result.append(URLEncoder.encode(key, "UTF-8"));
                result.append("=");
                result.append(URLEncoder.encode(value.toString(), "UTF-8"));

            }
            return result.toString();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED ) {

                    //   Toast.makeText(GetMailActivity.this, "got it", Toast.LENGTH_LONG).show();
                } else {
                    checkPermission(wantPermission);
                    Toast.makeText(AccountFormActivity.this, "  Permissions Denied.", Toast.LENGTH_LONG).show();
                }
                break;
        }
    }

    private void checkPermission(String wantPermission) {
    }

    //--------------
    private void checkAndRequestPermissions() {
        if (!hasPermissions(this, PERMISSIONS)) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
        }
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}

